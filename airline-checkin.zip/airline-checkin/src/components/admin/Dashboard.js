import React from "react";
import {connect} from "react-redux";
import * as passengerAction from "../../redux/actions/passengerAction";
import PropTypes from "prop-types";
import Select from 'react-select';
import {flights} from "../staticData/mataData";
import {bindActionCreators} from "redux";
import DateTimePicker from 'react-datetime-picker';

class Dashboard extends React.Component {
    state = {
      filterPassenger : {
        flightNumber: "",
        passport: "",
        dob:new Date(),
        address: ""
      },
      ancilaryFilter: {
        ancilaryflightNumber: "",
      }
      
    };

    flights = () =>{
        return (
            {flights}
        )
    }

    handleChange = (event) =>{
        const filterPassenger = {...this.state.filterPassenger, [event.target.id]: event.target.value};
        this.setState({filterPassenger});
    };

    handleDateChange = event => {
        const filterPassenger = {...this.state.filterPassenger, dob:event};
        debugger;
         this.setState({ filterPassenger});
    }

    handleChangeFlight = event => { 
        const filterPassenger = {...this.state.filterPassenger, flightNumber:event};
        debugger;
         this.setState({ filterPassenger});
    };

    handleChangeAncilaryFlight = event => { 
        const ancilaryFilter = {...this.state.ancilaryFilter, ancilaryflightNumber:event};
        debugger;
         this.setState({ ancilaryFilter});
    };

    addZero = i => {
        if (i < 10) {
            i = '0' + i;
        }
        return i;
    }

    formatDate = (date) => {
        let dateTime = '';
        let d = new Date(date),
            month = '' + this.addZero(d.getMonth() + 1),
            day = '' + this.addZero(d.getDate()),
            year = d.getFullYear();
        
        dateTime = [ year, month, day ].join('/') ;
        return dateTime;
    }
    formatDateTime = (date) => {
        let dateTime = '';
        let d = new Date(date),
            month = '' + this.addZero(d.getMonth() + 1),
            day = '' + this.addZero(d.getDate()),
            year = d.getFullYear();
        let hour = this.addZero(d.getHours());
        let min = this.addZero(d.getMinutes());
        
        dateTime = [ year, month, day ].join('/') + ' ' + hour + ':' + min ;
        return dateTime;
    }

    handleSubmit = event => {
        event.preventDefault();
        debugger;
        this.props.actions.filterPassenger(this.props.passengers, 
            this.state.filterPassenger.flightNumber.label,
            this.state.filterPassenger.passport,
            this.state.filterPassenger.dob,
            this.state.filterPassenger.address )
        console.log(this.state.filterPassenger);
    };

    handleAncilaryFilter = (flightAncilaryServices, flightNumber) => {
        console.log(flightAncilaryServices);
        debugger;
        this.props.actions.filterAncilaryAction(flightAncilaryServices, flightNumber)
    }

    render() {
        const {flightNumber} = this.state.filterPassenger
        const {ancilaryflightNumber} = this.state.ancilaryFilter
        return (
            <form onSubmit={this.handleSubmit}>
                <h4>Filter Passengers from  Flight</h4> <br/>
                <div className="container">
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="flightNumber">Select Flight Number*</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeFlight}  placeholder="select flight" options={flights} value={flightNumber} />
                        </div>
                    </div>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                        <label htmlFor="dob">Enter Date Of Birth*</label>
                        </div>
                        <div className="col-md-3">
                        <DateTimePicker format={"dd-MM-yyyy"} name="dob" id="dob" onChange={this.handleDateChange} value={this.state.filterPassenger.dob} />
                        </div>
                        <div className="col-md-3">
                        <label htmlFor="passport">Enter passport Number*</label>
                        </div>
                        <div className="col-md-3">
                        <input type="text" name="passport" id="passport" onChange={this.handleChange} value={this.state.filterPassenger.passport} />
                        </div>
                    </div>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="address">Enter Address</label>
                        </div>
                        <div className="col-md-3">
                            <input type="text" name="address" id="address" onChange={this.handleChange} value={this.state.filterPassenger.address} />
                        </div>
                        <div className="col-md-3" >
                            <input type="submit"   value="Search" />
                        </div>
                    </div>
                </div>
                <div className="container" style={{display:'block', width:'100%', height:'200px', overflow:'scroll'}}>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Flight</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Passenger Name</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Seat</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Passport</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Date of Birth</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Ancilary Services</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Address</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Sechduled Time</div>
                    </div>
                
                
                        {this.props.filterServiceList.map(passenger => (
                            <div className="row" key={passenger.passengerId}>
                                <div className="col-md-1" >{passenger.flightNumber.label}</div>
                                <div className="col-md-2" >{passenger.firstName +" "+passenger.lastName}</div>
                                <div className="col-md-1" >{passenger.seat}</div>
                                <div className="col-md-1" >{passenger.passport}</div>
                                <div className="col-md-1" >{this.formatDate(passenger.dob)}</div>
                                <div className="col-md-2" >{passenger.ancilaryServiceData.map(data => (data.label+","))}</div>
                                <div className="col-md-2" >{passenger.address}</div>
                                <div className="col-md-2" >{this.formatDateTime(passenger.scheduledTime)}</div>
                            </div>
                        ))}
                </div>

                <h4>Show the Ancilary service for Flight</h4> <br/>
                <div className="container">
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="flightNumber">Select Flight Number*</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeAncilaryFlight}  placeholder="select flight" options={flights} value={ancilaryflightNumber} />
                        </div>
                        <div className="col-md-3" >
                        <div className="col-md-3"><input type="button" value="Search" onClick={ () => {this.handleAncilaryFilter(this.props.flightAncilaryServices, ancilaryflightNumber.label)}} /></div>
                        </div>
                    </div>
                </div>
                <div className="container" style={{display:'block', width:'100%', height:'200px', overflow:'scroll'}}>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-4" style={{backgroundColor:"lightblue"}}>Flight</div>
                        <div className="col-md-4" style={{backgroundColor:"lightblue"}}>Service Name</div>
                        <div className="col-md-4" style={{backgroundColor:"lightblue"}}>Description</div>
                    </div>
                
                
                        {this.props.flightFilteredAncilaryList.map(service => (
                            <div className="row" key={service.id}>
                                <div className="col-md-4" >{service.flightNumber.label}</div>
                                <div className="col-md-4" >{service.ancilaryServices.label}</div>
                                <div className="col-md-4" >{service.ancilaryServices.value}</div>
                            </div>
                        ))}
                </div>
            </form>
                        
        )
    }
}

Dashboard.propsType = {
    passengers: PropTypes.array.isRequired,
    filterServiceList: PropTypes.array.isRequired,
    actions: PropTypes.object.isRequired
};


function mapStateToProps (state) {
    debugger;
    return {
        passengers: state.passengers,
        filterServiceList: state.filterServiceList,
        flightAncilaryServices: state.flightAncilaryServices,
        flightFilteredAncilaryList: state.flightFilteredAncilaryList
    };
}

function mapDispatchtoProps(dispatch) {
    return {
        actions: bindActionCreators( passengerAction , dispatch)
    }
}

export default connect(mapStateToProps,
    mapDispatchtoProps
    )(Dashboard);