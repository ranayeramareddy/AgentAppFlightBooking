import React from "react";
import Select from 'react-select';
import {flights, ancilary} from "../staticData/mataData";
import {connect} from "react-redux";
import * as ancilaryServiceAction from "../../redux/actions/AncilaryServiceAction";
import PropTypes from "prop-types";
import {bindActionCreators} from "redux";

class ManageFlightServices extends React.Component {

    state = {
        flightAncilaryService : {
            id: 0,
            flightNumber: "",
            ancilaryServices: "",
        },
        ancilaryList:[]
      };

      handleChangeFlightNumber = event => {
         const flightAncilaryService = {...this.state.flightAncilaryService, flightNumber:event};
         debugger;
          this.setState({ flightAncilaryService});
      }

      handleChangeServiceId = () => {
        const randomValue = Math.floor(Math.random()*899999+100000);
       // const flightAncilaryService = {...this.state.flightAncilaryService, id:randomValue};
        debugger;
        this.state.flightAncilaryService.id = randomValue;
     }

      handleChangeAncilaryService = event => {
        debugger;
        const flightAncilaryService = {...this.state.flightAncilaryService,  ancilaryServices:event};
        this.setState({ flightAncilaryService });
        
    }
    handleSubmit = (event) => {
        this.handleChangeServiceId();
        event.preventDefault();
        debugger;
        this.props.actions.createAction(this.state.flightAncilaryService)
    };

    handleDelete = (flightAncilaryServices, deleteId) => {
        console.log(flightAncilaryServices);
        debugger;
        this.props.actions.deleteAction(flightAncilaryServices, deleteId)
    }
    
    flights = () =>{
        return (
            {flights}
        )
    }

    ancilary = () => {
        return (
            {ancilary}
        )
    }
/*
    arrayList = () =>{
        let arrayList = [];
        this.props.addAncilaryServices.map(service => (
            arrayList.push({"label":service.serviceName, "value":service.serviceDesc})
        ))
        this.state.ancilaryList = arrayList
        return (
            this.state.ancilaryList
        )
    }
*/

       
        render () {
            debugger;
           const flightNumber = this.state.flightAncilaryService.flightNumber;
           const ancilaryServices = this.state.flightAncilaryService.ancilaryServices;
            return (
                <form onSubmit={this.handleSubmit}>
                    <h3>Manage Ancilary Service to Flight:</h3> <br/>
                    <div className="container">
                        <div className="row">
                            <div className="col-md-3">
                                <label htmlFor="flightNumber">Select Flight Number:</label>
                            </div>
                            <div className="col-md-3">
                                <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeFlightNumber} placeholder="select flight number" options={flights} value={flightNumber}>
                                </Select>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-3">
                                <label htmlFor="ancilaryService">Select Ancilary service:</label>
                            </div>
                            <div className="col-md-3">
                                <Select name="ancilaryService" id="ancilaryService" onChange={this.handleChangeAncilaryService} placeholder="select Ancilary service" options={ancilary} value={ancilaryServices} >
                                </Select>
                            </div>
                            <div className="col-md-3">
                                <input type="submit"  value="Add" />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-3">
                                <label htmlFor="id"></label>
                            </div>
                            <div className="col-md-3">
                                <input hidden={true} type="text" name="id" id="id" placeholder="auto generate number">
                                </input>
                            </div>
                        </div>

                    </div>
                    <div className="container" style={{display:'block', width:'100%', height:'200px', overflow:'scroll'}}>
                        <div className="row">
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Service Id</div>
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Flight Number</div>
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Ancilary Services</div>
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Action</div>
                        </div>
                        {this.props.flightAncilaryServices.map(service => (
                        
                        
                        <div className="row" key={service.id}>
                            <div className="col-md-3" >{service.id}</div>
                            <div className="col-md-3" >{service.flightNumber.value}</div>
                            <div className="col-md-3" >{service.ancilaryServices.label}</div>
                            <div className="col-md-3"><input type="button" value="Delete" onClick={ () => {this.handleDelete(this.props.flightAncilaryServices,service.id)}} /></div>
                        </div> ))}
                    </div>
                    
                </form>                      
                        
        )
        }      
    }
    
    
    ManageFlightServices.propsType = {
        flightAncilaryServices: PropTypes.array.isRequired,
        actions: PropTypes.object.isRequired
    };
    
    
    function mapStateToProps (state) {
        debugger;
        return {
            flightAncilaryServices: state.flightAncilaryServices
        };
    }
    
    function mapDispatchtoProps(dispatch) {
        return {
            actions: bindActionCreators( ancilaryServiceAction , dispatch)
        }
    }
    
    
    export default connect(mapStateToProps,
        mapDispatchtoProps
        )(ManageFlightServices);
