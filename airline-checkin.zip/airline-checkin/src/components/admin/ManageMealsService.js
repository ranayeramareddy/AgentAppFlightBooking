import React from "react";
import Select from 'react-select';
import {flights, mealsPreferences} from "../staticData/mataData";
import {connect} from "react-redux";
import * as mealPreferenceAction from "../../redux/actions/mealPreferenceAction";
import PropTypes from "prop-types";
import {bindActionCreators} from "redux";

class ManageMealsService extends React.Component {

    state = {
        flightMealsService : {
            id: 0,
            flightNumber: "",
            mealsPreference: ""
        }
      };

      handleChangeFlightNumber = event => {
         const flightMealsService = {...this.state.flightMealsService, flightNumber:event};
         debugger;
          this.setState({ flightMealsService});
      }
      handleChangeMeals = event => {
        const flightMealsService = {...this.state.flightMealsService, mealsPreference:event};
        debugger;
         this.setState({ flightMealsService});
     }
     
    

      handleChangeServiceId = () => {
        const randomValue = Math.floor(Math.random()*899999+100000);
       // const flightAncilaryService = {...this.state.flightAncilaryService, id:randomValue};
        debugger;
        this.state.flightMealsService.id = randomValue;
     }

    handleSubmit = (event) => {
        this.handleChangeServiceId();
        event.preventDefault();
        debugger;
        this.props.actions.createMealsPreferenceAction(this.state.flightMealsService)
    };

    handleDelete = (flightMealsService, deleteId) => {
        console.log(flightMealsService);
        debugger;
        this.props.actions.deleteMealsPerefrenecAction(flightMealsService, deleteId)
    }
    
    flights = () =>{
        return (
            {flights}
        )
    }

    mealsPreferences = () => {
        return (
            {mealsPreferences}
        )
    }

    

        render () {
            debugger;
           const flightNumber = this.state.flightMealsService.flightNumber;
           const mealsPreference = this.state.flightMealsService.mealsPreference;
           
            return (
                <form onSubmit={this.handleSubmit}>
                    <h3>Manage Shopping/Meals Service per Flight:</h3> <br/>
                    <div className="container">
                        <div className="row">
                            <div className="col-md-3">
                                <label htmlFor="flightNumber">Select Flight Number:</label>
                            </div>
                            <div className="col-md-3">
                                <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeFlightNumber} placeholder="select flight number" options={flights} value={flightNumber}>
                                </Select>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-3">
                                <label htmlFor="mealsPreference">Select special meals:</label>
                            </div>
                            <div className="col-md-3">
                                <Select name="mealsPreference" id="mealsPreference" onChange={this.handleChangeMeals} placeholder="select meals" options={mealsPreferences} value={mealsPreference} >
                                </Select>
                            </div>
                        
                            <div className="col-md-3">
                                <input type="submit"  value="Add" />
                            </div>
                        </div>

                    </div>
                    <div className="container" style={{display:'block', width:'100%', height:'200px', overflow:'scroll'}}>
                        <div className="row">
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Service Id</div>
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Flight Number</div>
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Meals Preference</div>
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Action</div>
                        </div>

                        {this.props.mealsPreferencePerFlight.map(service => (
                        
                        <div className="row" key={service.id}>
                            <div className="col-md-3" >{service.id}</div>
                            <div className="col-md-3" >{service.flightNumber.value}</div>
                            <div className="col-md-3" >{service.mealsPreference.label}</div>
                           
                            <div className="col-md-3"><input type="button" value="Delete" onClick={ () => {this.handleDelete(this.props.mealsPreferencePerFlight,service.id)}} /></div>
                        </div> ))}
                    </div>
                    
                </form>                      
                        
        )
        }      
    }
    
    
    ManageMealsService.propsType = {
        mealsPreferencePerFlight: PropTypes.array.isRequired,
        actions: PropTypes.object.isRequired
    };
    
    
    function mapStateToProps (state) {
        debugger;
        return {
            mealsPreferencePerFlight: state.mealsPreferencePerFlight
        };
    }
    
    function mapDispatchtoProps(dispatch) {
        return {
            actions: bindActionCreators( mealPreferenceAction , dispatch)
        }
    }
    
    
    export default connect(mapStateToProps,
        mapDispatchtoProps
        )(ManageMealsService);
