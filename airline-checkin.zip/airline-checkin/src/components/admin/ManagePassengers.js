import React from "react";
import {connect} from "react-redux";
import * as passengerAction from "../../redux/actions/passengerAction";
import PropTypes from "prop-types";
import Select from 'react-select';
import {flights} from "../staticData/mataData";
import {bindActionCreators} from "redux";


class ManagePassengers extends React.Component {
    state = {
      managePassenger : {
        flightNumber: "",
        passengerList: ""
      }
      
    };

    flights = () =>{
        return (
            {flights}
        )
    }

    handleChangeFlight = event => { 
        const managePassenger = {...this.state.managePassenger, flightNumber:event};
        debugger;
         this.setState({ managePassenger});
    };

    addZero = i => {
        if (i < 10) {
            i = '0' + i;
        }
        return i;
    }

    formatDate = (date) => {
        let dateTime = '';
        let d = new Date(date),
            month = '' + this.addZero(d.getMonth() + 1),
            day = '' + this.addZero(d.getDate()),
            year = d.getFullYear();
        
        dateTime = [ year, month, day ].join('/') ;
        return dateTime;
    }
    formatDateTime = (date) => {
        let dateTime = '';
        let d = new Date(date),
            month = '' + this.addZero(d.getMonth() + 1),
            day = '' + this.addZero(d.getDate()),
            year = d.getFullYear();
        let hour = this.addZero(d.getHours());
        let min = this.addZero(d.getMinutes());
        
        dateTime = [ year, month, day ].join('/') + ' ' + hour + ':' + min ;
        return dateTime;
    }

    handleSubmit = event => {
        event.preventDefault();
        debugger;
        this.props.actions.searchPassenger(this.props.passengers, this.state.managePassenger.flightNumber.label)
        console.log(this.state.managePassenger);
    };

    handleDelete = (passengers, deleteId) => {
        console.log(passengers);
        debugger;
        this.props.actions.deletePassenger(passengers, deleteId)
    }

    render() {
        const {flightNumber} = this.state.managePassenger
        return (
            <form onSubmit={this.handleSubmit}>
                <h4>Manage Passenegers to flight</h4> <br/>
                <div className="container">
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="flightNumber">Select Flight Number*</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeFlight}  placeholder="select flight" options={flights} value={flightNumber} />
                        </div>
                        <div className="col-md-3" >
                            <input type="submit"   value="Search" />
                        </div>
                    </div>
                </div>
                <div className="container" style={{display:'block', width:'100%', height:'300px', overflow:'scroll'}}>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Flight</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Passenger Name</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Seat</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Passport</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Date of Birth</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Ancilary Services</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Address</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Sechduled Time</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Action</div>
                    </div>
                
                
                        {this.props.filterPassengerList.map(passenger => (
                            <div className="row" key={passenger.passengerId}>
                                <div className="col-md-1" >{passenger.flightNumber.label}</div>
                                <div className="col-md-2" >{passenger.firstName +" "+passenger.lastName}</div>
                                <div className="col-md-1" >{passenger.seat}</div>
                                <div className="col-md-1" >{passenger.passport}</div>
                                <div className="col-md-1" >{this.formatDate(passenger.dob)}</div>
                                <div className="col-md-2" >{passenger.ancilaryServiceData.map(data => (data.label+","))}</div>
                                <div className="col-md-1" >{passenger.address}</div>
                                <div className="col-md-2" >{this.formatDateTime(passenger.scheduledTime)}</div>
                                <div className="col-md-1"><input type="button" value="Delete" onClick={ () => {this.handleDelete(this.props.passengers, passenger.passengerId)}} /></div>
                            </div>
                        ))}
                </div>

            </form>
            
        )
    }
}

ManagePassengers.propsType = {
    passengers: PropTypes.array.isRequired,
    filterPassengerList: PropTypes.array.isRequired,
    actions: PropTypes.object.isRequired
};


function mapStateToProps (state) {
    debugger;
    return {
        passengers: state.passengers,
        filterPassengerList: state.filterPassengerList
    };
}

function mapDispatchtoProps(dispatch) {
    return {
        actions: bindActionCreators( passengerAction , dispatch)
    }
}

export default connect(mapStateToProps,
    mapDispatchtoProps
    )(ManagePassengers);