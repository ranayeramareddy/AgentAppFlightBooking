import React from "react";
import Select from 'react-select';
import {flights, shoppingRequests} from "../staticData/mataData";
import {connect} from "react-redux";
import * as shoppingRequestAction from "../../redux/actions/shoppingRequestAction";
import PropTypes from "prop-types";
import {bindActionCreators} from "redux";

class ManageShoppingRequest extends React.Component {

    state = { 
        flightShoppingService : {
            id: 0,
            flightNumber: "",
            shoppingRequest: ""
        }
      };

      handleChangeFlightNumber = event => {
         const flightShoppingService = {...this.state.flightShoppingService, flightNumber:event};
         debugger;
          this.setState({ flightShoppingService});
      }
     
     handleChangeShopping = event => {
        const flightShoppingService = {...this.state.flightShoppingService, shoppingRequest:event};
        debugger;
         this.setState({ flightShoppingService});
     }

      handleChangeServiceId = () => {
        const randomValue = Math.floor(Math.random()*899999+100000);
        debugger;
        this.state.flightShoppingService.id = randomValue;
     }

    handleSubmit = (event) => {
        this.handleChangeServiceId();
        event.preventDefault();
        debugger;
        this.props.actions.createShoppingRequestAction(this.state.flightShoppingService)
    };

    handleDelete = (flightShoppingService, deleteId) => {
        console.log(flightShoppingService);
        debugger;
        this.props.actions.deleteShoppingRequestAction(flightShoppingService, deleteId)
    }
    
    flights = () =>{
        return (
            {flights}
        )
    }

    shoppingRequests = () => {
        return (
            {shoppingRequests}
        )
    }

        render () {
            debugger;
           const flightNumber = this.state.flightShoppingService.flightNumber;
           const shoppingRequest = this.state.flightShoppingService.shoppingRequest;
            return (
                <form onSubmit={this.handleSubmit}>
                    <h3>Manage Shopping Request items per Flight:</h3> <br/>
                    <div className="container">
                        <div className="row">
                            <div className="col-md-3">
                                <label htmlFor="flightNumber">Select Flight Number:</label>
                            </div>
                            <div className="col-md-3">
                                <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeFlightNumber} placeholder="select flight number" options={flights} value={flightNumber}>
                                </Select>
                            </div>
                        </div>
                       
                        <div className="row">
                            <div className="col-md-3">
                                <label htmlFor="shoppingRequest">Select Shopping request:</label>
                            </div>
                            <div className="col-md-3">
                                <Select name="shoppingRequest" id="shoppingRequest" onChange={this.handleChangeShopping} placeholder="select shopping items" options={shoppingRequests} value={shoppingRequest} >
                                </Select>
                            </div>
                            <div className="col-md-3">
                                <input type="submit"  value="Add" />
                            </div>
                        </div>

                    </div>
                    <div className="container" style={{display:'block', width:'100%', height:'200px', overflow:'scroll'}}>
                        <div className="row">
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Service Id</div>
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Flight Number</div>
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Shopping Request Items</div>
                            <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Action</div>
                        </div>

                        {this.props.shoppingRequestPerFlight.map(service => (
                        
                        <div className="row" key={service.id}>
                            <div className="col-md-3" >{service.id}</div>
                            <div className="col-md-3" >{service.flightNumber.value}</div>
                            <div className="col-md-3" >{service.shoppingRequest.label}</div>
                            <div className="col-md-3"><input type="button" value="Delete" onClick={ () => {this.handleDelete(this.props.shoppingRequestPerFlight,service.id)}} /></div>
                        </div> ))}
                    </div>
                    
                </form>                      
                        
        )
        }      
    }
    
    
    ManageShoppingRequest.propsType = {
        shoppingRequestPerFlight: PropTypes.array.isRequired,
        actions: PropTypes.object.isRequired
    };
    
    
    function mapStateToProps (state) {
        debugger;
        return {
            shoppingRequestPerFlight: state.shoppingRequestPerFlight
        };
    }
    
    function mapDispatchtoProps(dispatch) {
        return {
            actions: bindActionCreators( shoppingRequestAction , dispatch)
        }
    }
    
    
    export default connect(mapStateToProps,
        mapDispatchtoProps
        )(ManageShoppingRequest);
