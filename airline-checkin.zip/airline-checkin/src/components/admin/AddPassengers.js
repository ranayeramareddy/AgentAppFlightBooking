import React from "react";
import {connect} from "react-redux";
import * as passengerAction from "../../redux/actions/passengerAction";
import PropTypes from "prop-types";
import Select from 'react-select';
import {flights, countries, states, cities} from "../staticData/mataData";
import {bindActionCreators} from "redux";
import DateTimePicker from 'react-datetime-picker';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';

class AddPassengers extends React.Component {
    state = {
      passenger : {
        flightNumber: "",
        passengerId:0,
        firstName:"",
        lastName:"",
        seat:"",
        dob:new Date(),
        address:"",
        country: "",
        state: "",
        city: "",
        mobile:"",
        email:"",
        passport:"",
        scheduledTime:new Date(),
        ancilaryServiceData:[],
        checkin: false,
        wheelChair: false,
        infants: false,
        specialMeals: false,
        mealsPreference: [],
        shoppingRequest: []
      }
      
    };


    flights = () =>{
        return (
            {flights}
        )
    }
    countries = () =>{
        return (
            {countries}
        )
    }
    states = () =>{
        return (
            {states}
        )
    }
    cities = () =>{
        return (
            {cities}
        )
    }

    /*seatNumbers = () =>{
        return (
            {seatNumbers}
        )
    }*/

    handleChange = (event) =>{
        const passenger = {...this.state.passenger, [event.target.id]: event.target.value};
        this.setState({passenger});
    };

    handleCheckBoxs = name => event => {
        debugger;
       const passenger = {...this.state.passenger, [name]: event.target.checked};
       this.setState({passenger});
      };

   /* handleCheckWheelChair = (event) => {
        debugger;
        const passenger = {...this.state.passenger, wheelChair: event.target.checked};
        this.setState({passenger});
    };*/

    handleDateChange = event => {
        const passenger = {...this.state.passenger, dob:event};
        debugger;
         this.setState({ passenger});
    }

    handleDateChangeScheduledTime = event => {
        const passenger = {...this.state.passenger, scheduledTime:event};
        debugger;
         this.setState({ passenger});
    }
/*
    handleChangeSeat = event => { 
        const passenger = {...this.state.passenger, seat:event};
        debugger;
         this.setState({ passenger});
    };
*/
    handleChangeAncilaryData = event => { 
        const passenger = {...this.state.passenger, ancilaryServiceData:event};
        debugger;
         this.setState({ passenger});
    };
   
    handleChangeFlight = event => { 
        const passenger = {...this.state.passenger, flightNumber:event};
        debugger;
         this.setState({ passenger});
    };
    handleChangeCountry = event =>{ 
        const passenger = {...this.state.passenger, country:event};
        debugger;
         this.setState({ passenger});
    };
    handleChangeState = event =>{ 
        const passenger = {...this.state.passenger, state:event};
        debugger;
         this.setState({ passenger});
    };
    handleChangeCity = event =>{ 
        const passenger = {...this.state.passenger, city:event};
        debugger;
         this.setState({ passenger});
    };

    handleChangePassengerId = () => {
        const randomValue = Math.floor(Math.random()*899999+100000);
        debugger;
        this.state.passenger.passengerId = randomValue
    }

    addZero = i => {
        if (i < 10) {
            i = '0' + i;
        }
        return i;
    }

    formatDate = (date) => {
        let dateTime = '';
        let d = new Date(date),
            month = '' + this.addZero(d.getMonth() + 1),
            day = '' + this.addZero(d.getDate()),
            year = d.getFullYear();
        let hour = this.addZero(d.getHours());
        let min = this.addZero(d.getMinutes());
        let sec = this.addZero(d.getSeconds());
        dateTime = [ year, month, day ].join('/') + ' ' + hour + ':' + min ;
        return dateTime;
    }

    handleSubmit = event => {
        this.handleChangePassengerId();
        event.preventDefault();
        this.props.actions.createPassenger(this.state.passenger)
        console.log(this.state.passenger);
    };

   /* arrayList = () =>{
        let arrayList = [];
        this.props.addAncilaryServices.map(service => (
            arrayList.push({"label":service.serviceName, "value":service.serviceDesc})
        ))
        this.state.passenger.ancilaryServiceData = arrayList
        return (
            this.state.passenger.ancilaryServiceData
        )
    }*/

    ancilaryList = () => {
        let arrayList = [];
        this.props.flightAncilaryServices.map(service => ((service.flightNumber !== null && service.flightNumber !== "" && service.flightNumber !== undefined) ? (service.flightNumber.label === this.state.passenger.flightNumber.label) ?
            arrayList.push({"label":service.ancilaryServices.label, "value":service.ancilaryServices.value})
            :  console.log("no ancilary for this flight")
            :  console.log("no valid flight number")
            ))
        return (
            arrayList
        )
    }

    render() {
        const {flightNumber} = this.state.passenger
        const {country} = this.state.passenger
        const {state} = this.state.passenger
        const {city} = this.state.passenger
        const {ancilaryServiceData} = this.state.passenger
        return (
            <form onSubmit={this.handleSubmit}>
                <h4>Add Passenegers to the flight</h4> <br/>
                <div className="container" >
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="flightNumber">Select Flight Number*</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeFlight}  placeholder="select flight" options={flights} value={flightNumber} />
                        </div>
                    </div>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="firstName">Enter FirstName*</label>
                        </div>
                        <div className="col-md-3">
                            <input type="text" name="firstName" id="firstName" onChange={this.handleChange} value={this.state.passenger.firstName} />
                        </div>
                        <div className="col-md-3">
                            <label htmlFor="lastName">Enter LastName*</label>
                        </div>
                        <div className="col-md-3">
                            <input type="text" name="lastName" id="lastName" onChange={this.handleChange} value={this.state.passenger.lastName} />
                        </div>
                    </div>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                        <label htmlFor="dob">Enter Date Of Birth*</label>
                        </div>
                        <div className="col-md-3">
                        <DateTimePicker format={"dd-MM-yyyy"} name="dob" id="dob" onChange={this.handleDateChange} value={this.state.passenger.dob} />
                        </div>
                        <div className="col-md-3">
                            <label htmlFor="address">Enter Address</label>
                        </div>
                        <div className="col-md-3">
                            <input type="text" name="address" id="address" onChange={this.handleChange} value={this.state.passenger.address} />
                        </div>
                    </div>
                    <div className="row" style={{padding:'5px'}} >
                        <div className="col-md-3">
                            <label htmlFor="country">Select Country</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="country" id="country" onChange={this.handleChangeCountry}  placeholder="select country" options={countries} value={country}>
                            </Select>
                        </div>
                        <div className="col-md-3">
                            <label htmlFor="state">Select State</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="state" id="state" onChange={this.handleChangeState}  placeholder="select state" options={states}  value={state} >
                            </Select>
                        </div>
                    </div>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="city">Select City</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="city" id="city" onChange={this.handleChangeCity}  placeholder="select city" options={cities}  value={city}>
                            </Select>
                        </div>
                        <div className="col-md-3">
                            <label htmlFor="mobile">Enter Mobile*</label>
                        </div>
                        <div className="col-md-3">
                            <input type="text" name="mobile" id="mobile" onChange={this.handleChange} value={this.state.passenger.mobile} />
                        </div>
                    </div>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="email">Enter Email</label>
                        </div>
                        <div className="col-md-3">
                            <input type="text" name="email" id="email" onChange={this.handleChange} value={this.state.passenger.email} />
                        </div>
                    
                        <div className="col-md-3">
                        <label htmlFor="passport">Enter passport Number*</label>
                        </div>
                        <div className="col-md-3">
                        <input type="text" name="passport" id="passport" onChange={this.handleChange} value={this.state.passenger.passport} />
                        </div>
                    </div>
                    <div className="row" style={{padding:'5px'}}>
                        
                        <div className="col-md-3">
                           
                            <FormControlLabel
                                control={
                                <Checkbox
                                    checked={this.state.passenger.infants}
                                    onChange={this.handleCheckBoxs('infants')}
                                    value={'infants'}
                                    color="primary"
                                />
                                }
                                label="Is Infants are there ?"
                            />
                        
                        </div>
                        
                        <div className="col-md-3">
                            <FormControlLabel
                                    control={
                                    <Checkbox
                                        checked={this.state.passenger.wheelChair}
                                        onChange={this.handleCheckBoxs('wheelChair')}
                                        value={'wheelChair'}
                                        color="primary"
                                    />
                                    }
                                    label="Is Passenger required Wheel Chair?"
                                />
                        </div>
                        <div className="col-md-3">
                            <FormControlLabel
                                    control={
                                    <Checkbox
                                        checked={this.state.passenger.specialMeals}
                                        onChange={this.handleCheckBoxs('specialMeals')}
                                        value={'specialMeals'}
                                        color="primary"
                                    />
                                    }
                                    label="Is Passenger required special Meals?"
                                />
                        </div>
                    </div>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3" >
                            <label htmlFor="scheduledTime">Schedule Time</label>
                        </div>
                        <div className="col-md-3">
                        <DateTimePicker format={"dd-MM-yyyy hh:mm"} name="scheduledTime" id="scheduledTime" onChange={this.handleDateChangeScheduledTime} value={this.state.passenger.scheduledTime} />
                        </div>
                        <div className="col-md-3">
                            <label htmlFor="ancilaryServiceData">Select Ancilary Service</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="ancilaryServiceData" id="ancilaryServiceData" onChange={this.handleChangeAncilaryData}  placeholder="ancilary services" options={this.ancilaryList()} value={ancilaryServiceData} isMulti/>
                        </div>
                        <div className="col-md-3" >
                            <input type="submit"   value="AddPassenger" />
                        </div>
                    </div>
                </div>
                <div className="container" style={{display:'block', width:'100%', height:'300px', overflow:'scroll'}}>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Passenger Id</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Passenger Name</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Flight Number</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Seat</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Scheduled Time</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Passport</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Address</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Ancilary Services</div>
                    </div>
                
                
                        {this.props.passengers.map(passenger => (
                            
                                <div className="row" key={passenger.passengerId} style={{'padding':'5px'}}>
                                    <div className="col-md-1" >{passenger.passengerId}</div>
                                    <div className="col-md-2" >{passenger.firstName +" "+passenger.lastName}</div>
                                    <div className="col-md-1" >{passenger.flightNumber.label}</div>
                                    <div className="col-md-1" >{passenger.seat}</div>
                                    <div className="col-md-2" >{this.formatDate(passenger.scheduledTime)}</div>
                                    <div className="col-md-1" >{passenger.passport}</div>
                                    <div className="col-md-2" >{passenger.address}</div>
                                    <div className="col-md-2" >{(passenger.ancilaryServiceData.length > 0 ) ? passenger.ancilaryServiceData.map(data => (data.label+",")) : console.log("no ancilary")}</div>
                                </div>
                        ))}
                </div>

            </form>
            
        )
    }
}

AddPassengers.propsType = {
    passengers: PropTypes.array.isRequired,
    flightAncilaryServices: PropTypes.array.isRequired,
    actions: PropTypes.object.isRequired
};


function mapStateToProps (state) {
    return {
        passengers: state.passengers,
        flightAncilaryServices: state.flightAncilaryServices
    };
}

function mapDispatchtoProps(dispatch) {
    return {
        //createPassenger: passenger => dispatch(passengerAction.createPassenger(passenger))
        actions: bindActionCreators( passengerAction , dispatch)
    }
}

export default connect(mapStateToProps,
    mapDispatchtoProps
    )(AddPassengers);