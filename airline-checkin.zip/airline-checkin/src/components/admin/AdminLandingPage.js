import React from 'react';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Paper from '@material-ui/core/Paper';
import AddPassengers from './AddPassengers';
import ManageMealsService from './ManageMealsService';
import ManageShoppingRequest from './ManageShoppingRequest'
import Dashboard from './Dashboard';
import ManageFlightServices from './ManageFlightServices';
import ManagePassengers from './ManagePassengers';
import Footer from '../Footer'

export default class AdminLandingPage extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            value: 0
        }
    }

    handleChange = (event, newValue) => {
        this.setState({ value: newValue });
    };

    
    displaySelectedTab = (param) => {
        switch (param) {
            case 0:
                return <AddPassengers/>
            case 1:
                return <ManagePassengers />
            case 2:
                return <ManageShoppingRequest />
            case 3:
                return <ManageMealsService />
            case 4:
                return <ManageFlightServices />
            default:
                return <Dashboard  />
        }
    }

    render() {
        return (<div>
            <Paper square>
                <Tabs
                    value={this.state.value}
                    onChange={this.handleChange}
                    variant="fullWidth"
                    indicatorColor="primary"
                    textColor="primary"
                    aria-label="icon tabs example"
                >
                    <Tab
                        label='Add Passengers'
                    />
                    <Tab label="Manage Passengers"
                    />
                    <Tab label="Manage Shopping Srevices"
                    />
                    <Tab label="Manage InFlight Meals Services "
                    />
                    <Tab label="Manage Ancilary Flight Services "
                    />
                    <Tab label="Dashboard"
                    />
                </Tabs>
            </Paper>
            {this.displaySelectedTab(this.state.value)}

            <Footer />
        </div>);
    }
}