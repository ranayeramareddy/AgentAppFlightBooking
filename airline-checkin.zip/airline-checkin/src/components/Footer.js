import React from "react"

const Footer = () => (
    <div className = "footer">
        <p>@ copyright's are belongs to airline checkin application, All Rights Reserved. Terms - Privacy</p>
    </div>

);

export default Footer