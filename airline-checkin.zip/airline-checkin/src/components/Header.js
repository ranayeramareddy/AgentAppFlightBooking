import React from "react"
import NavBar from "./admin/NavBar"
import StaffBar from "./staff/StaffBar"
const Header = (props) => {
    return (
        <div className="header">
            {(props.userRole === 'admin' ?  <h2>Welcome to Admin </h2> :
                        props.userRole === 'staff' ?  <h2>Welcome to Staff </h2> : <div></div>)
    }
    
                        </div>
    )
}

export default Header