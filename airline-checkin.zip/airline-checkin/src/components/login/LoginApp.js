import React from 'react';
import GoogleLogin from 'react-google-login';
import { GoogleLogout } from 'react-google-login';
import PropTypes from 'prop-types';

export default class LoginApp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userLoggedIn: false,
            userMessage: ''
        }
    }
    
     responseGoogleOnSucess = (response) => {
         console.log(response);
         this.setState({ userLoggedIn: true, userMessage: response.profileObj.name });
         let role = 'otherRole';
         if (response.profileObj.email === 'practicereact2011@gmail.com')
         {
             role = 'admin';
         } else if (response.profileObj.email === 'practicspring2012@gmail.com') {
             role = 'staff';
         }   
         this.props.isAuthorized(true, role);
    }


    responseGoogleOnFailure = (response) => {
        console.log(response);
        this.setState({ userLoggedIn: false, userMessage: 'Login failed.' });
        this.props.isAuthorized(false,'NA');
    }

    logout = (response) => {
        console.log(response);
        this.setState({ userLoggedIn: false, userMessage: '' });
        this.props.isAuthorized(false,'NA');
    }

    render() {
        return (
            <div>
                <div>{this.state.userMessage}</div>

                <div>{!this.state.userLoggedIn ?
                    <GoogleLogin
                        clientId="1019281859008-8r80e7jur1ppsfkq69nuud052sp9m5ub.apps.googleusercontent.com"
                        buttonText="Login"
                        onSuccess={this.responseGoogleOnSucess}
                        onFailure={this.responseGoogleOnFailure}
                        cookiePolicy={'single_host_origin'}
                    /> :
                    <GoogleLogout
                        clientId="1019281859008-8r80e7jur1ppsfkq69nuud052sp9m5ub.apps.googleusercontent.com"
                        buttonText="Logout"
                        onLogoutSuccess={this.logout}
                    />}
                </div>
                </div>
                );
                }
}

LoginApp.propTypes = {
    isAuthorized: PropTypes.func
}