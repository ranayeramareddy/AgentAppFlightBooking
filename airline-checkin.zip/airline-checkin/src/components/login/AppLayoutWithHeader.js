import React from 'react';
import LoginApp from './LoginApp';
import Grid from '@material-ui/core/Grid';
import AdminLandingPage from '../admin/AdminLandingPage';
import AirlineStaffLandingPage from '../staff/AirlineStaffLandingPage';

export default class AppLayoutWithHeader extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isAuthorized: false,
            userRole:'admin'
        }
    }

    updateIsAuthorized = (authorizedVale, userRole) => {
        this.setState({ isAuthorized: authorizedVale, userRole: userRole})
    }

    render() {
        return (
            <div> 
               <Grid container style={{display:'flex'}}>
                    <Grid item xs={9} sm={9} style={{
                        textAlign: 'center', background: '#5cbeae',
                        color: 'white' }}><h1>Airline Checkin Application</h1></Grid>
                    <Grid item xs={3} sm={3} style={{ textAlign: 'center', background: '#5cbeae',
                        color: 'white'
                    }}><LoginApp isAuthorized={this.updateIsAuthorized} /></Grid>
                </Grid>

              
                {this.state.isAuthorized && this.state.userRole !== 'otherRole' ?
                    (this.state.userRole === 'admin' ? <AdminLandingPage /> :
                        this.state.userRole === 'staff' ? <AirlineStaffLandingPage /> : <div></div>)
                    :
                    <Grid container>
                        {this.state.userRole === 'otherRole' ?
                            <Grid item xs={12} sm={12} ><h5>'You are not authorized!' </h5></Grid> : ''}
                        <Grid item xs={12} sm={12} >
                            <div style={{ paddingLeft: '20px' }}>
                                <h5>Please use the below Login Credentails</h5>
                                <div>practicereact2011@gmail.com/airlineadmin</div>
                                <div>practicspring2012@gmail.com/airlinestaff</div>
                            </div>
                        </Grid>
                    </Grid>
                }
                
                </div>
        );
    }
}