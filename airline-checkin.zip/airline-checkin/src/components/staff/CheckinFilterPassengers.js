import React from "react";
import {connect} from "react-redux";
import * as filterPassengerAction from "../../redux/actions/passengerAction";
import PropTypes from "prop-types";
import Select from 'react-select';
import {flights} from "../staticData/mataData";
import {bindActionCreators} from "redux";
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';


class CheckinFilterPassengers extends React.Component {
    state = {
      filterPassengers : {
        flightNumber: "",
        checkin: false,
        infants: false,
        wheelChair: false,
      },
    };

    flights = () =>{
        return (
            {flights}
        )
    }

    handleCheckBoxs = name => event => {
        debugger;
       const filterPassengers = {...this.state.filterPassengers, [name]: event.target.checked};
       this.setState({filterPassengers});
      };

    handleChangeFlight = event => { 
        const filterPassengers = {...this.state.filterPassengers, flightNumber:event};
        debugger;
         this.setState({ filterPassengers});
    };

    addZero = i => {
        if (i < 10) {
            i = '0' + i;
        }
        return i;
    }

    formatDate = (date) => {
        let dateTime = '';
        let d = new Date(date),
            month = '' + this.addZero(d.getMonth() + 1),
            day = '' + this.addZero(d.getDate()),
            year = d.getFullYear();
        dateTime = [ year, month, day ].join('/') ;
        return dateTime;
    }
    formatDateTime = (date) => {
        let dateTime = '';
        let d = new Date(date),
            month = '' + this.addZero(d.getMonth() + 1),
            day = '' + this.addZero(d.getDate()),
            year = d.getFullYear();
        let hour = this.addZero(d.getHours());
        let min = this.addZero(d.getMinutes());
        dateTime = [ year, month, day ].join('/') + ' ' + hour + ':' + min ;
        return dateTime;
    }

    handleSubmit = event => {
        const {flightNumber, checkin, infants, wheelChair } = this.state.filterPassengers
        event.preventDefault();
        debugger;
        this.props.actions.filterCheckinPassengerAction(this.props.passengers, flightNumber.label, checkin, infants, wheelChair)
        console.log(this.state.filterPassengers);
    };


    render() {
        const {flightNumber} = this.state.filterPassengers
       
        return (
            <form onSubmit={this.handleSubmit}>
                <h5> Filter Passengers in Flight :{flightNumber.label}</h5> <br/>
                <div className="container">
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="flightNumber">Chose Flight to show passengers*</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeFlight}  placeholder="select flight" options={flights} value={flightNumber} />
                        </div>
                    </div>
                    <div className="row" style={{'padding':'5px'}}>
                        <div className="col-md-3">
                            <FormControlLabel
                                control={
                                <Checkbox
                                    checked={this.state.filterPassengers.checkin}
                                    onChange={this.handleCheckBoxs('checkin')}
                                    value={'checkin'}
                                    color="primary"
                                />
                                }
                                label="Check-In"
                            />
                        </div>
                        <div className="col-md-3">
                            <FormControlLabel
                                control={
                                <Checkbox
                                    checked={this.state.filterPassengers.infants}
                                    onChange={this.handleCheckBoxs('infants')}
                                    value={'infants'}
                                    color="primary"
                                />
                                }
                                label="Infants"
                            />
                        </div>
                        <div className="col-md-3">
                            <FormControlLabel
                                    control={
                                    <Checkbox
                                        checked={this.state.filterPassengers.wheelChair}
                                        onChange={this.handleCheckBoxs('wheelChair')}
                                        value={'wheelChair'}
                                        color="primary"
                                    />
                                    }
                                    label="Wheel Chair"
                                />
                        </div>
                        <div className="col-md-3" >
                            <input type="submit"   value="Search" style={{backgroundColor:"lightblue"}} />
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-4" > <label style={{backgroundColor:"rgb(218, 170, 170)"}}>*please select any one of the above check box and click on search buttton</label></div>
                    </div>
                </div>
                <div className="container" style={{display:'block', width:'100%', height:'200px', overflow:'scroll'}}>
                    <div className="row" style={{'padding':'5px'}}>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Passenger Id</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Passenger Name</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Seat</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Passport</div>
                        <div className="col-md-4" style={{backgroundColor:"lightblue"}}>Ancilary Services</div>
                        <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Sechduled Time</div>
                    </div>
             
                
                        {this.props.filterCheckinPassenger.map(passenger => (
                            (passenger.flightNumber.label === flightNumber.label) ?
                            <div className="row" key={passenger.passengerId}>
                                <div className="col-md-1" >{passenger.passengerId}</div>
                                <div className="col-md-2" >{passenger.firstName +" "+passenger.lastName}</div>
                                <div className="col-md-1" >{passenger.seat}</div>
                                <div className="col-md-1" >{passenger.passport}</div>
                                <div className="col-md-4" >{passenger.ancilaryServiceData.map(data => (data.label+","))}</div>
                                <div className="col-md-3" >{this.formatDateTime(passenger.scheduledTime)}</div>
                            </div>
                            : console.log("no passengers for selected flight")
                        ))}
                </div>
            </form>
                        
        )
    }
}

CheckinFilterPassengers.propsType = {
    passengers: PropTypes.array.isRequired,
    actions: PropTypes.object.isRequired
};


function mapStateToProps (state) {
    debugger;
    return {
        passengers: state.passengers,
        filterCheckinPassenger: state.filterCheckinPassenger
    };
}

function mapDispatchtoProps(dispatch) {
    return {
        actions: bindActionCreators( filterPassengerAction , dispatch)
    }
}

export default connect(mapStateToProps,
    mapDispatchtoProps
    )(CheckinFilterPassengers);