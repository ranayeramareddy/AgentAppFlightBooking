import React from 'react';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Paper from '@material-ui/core/Paper';
import CheckinPassengerService from './CheckinPassengerService';
import CheckinFilterPassengers from './CheckinFilterPassengers';
import InFlightDashboard from './InFlightDashboard';
import InFlightAncilaryService from './InFlightAncilaryService';
import ManageInFlightService from './ManageInFlightService';
import Footer from '../Footer';
import AirlineCheckinDashboard from "./AirlineCheckinDashboard"

export default class AirlineStaffLandingPage extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            value: 0
        }
    }

    handleChange = (event, newValue) => {
        this.setState({ value: newValue });
    };

    
    displaySelectedTab = (param) => {
        switch (param) {
            case 0:
                return <AirlineCheckinDashboard/>
            case 1:
                return <CheckinPassengerService />
            case 2:
                return <CheckinFilterPassengers />
            case 3:
                return <InFlightDashboard />
            case 4:
                return <InFlightAncilaryService  />
            case 5:
                return <ManageInFlightService  />
            default:
                return <AirlineCheckinDashboard  />
        }
    }

    render() {
        return (<div>
            <Paper square>
                    <Tabs value={this.state.value}
                        onChange={this.handleChange}
                        variant="fullWidth"
                        indicatorColor="primary"
                        textColor="primary"
                        aria-label="icon tabs example"
                    >
                        <Tab label="Check-In Dashboard"/>
                        <Tab label="Display Passengers" />
                        <Tab label="Filter Passengers" />
                        <Tab label="In-Flight Dashboard" />
                        <Tab label="Manage Ancilary Service" />
                        <Tab label="Manage In-Flight Services" />

                    </Tabs>
            </Paper>
            {this.displaySelectedTab(this.state.value)}
            <Footer />
        </div>);
    }
}