import React from "react";
import {connect} from "react-redux";
import * as passengerAction from "../../redux/actions/passengerAction";
import PropTypes from "prop-types";
import Select from 'react-select';
import {flights} from "../staticData/mataData";
import {bindActionCreators} from "redux";

class ManageInFlightService extends React.Component {
    state = {
      manageInflightPassengers : {
        flightNumber: "",
        passengerId: "",
        mealsPreference: [],
        shoppingRequest:[]
      }
    };

    flights = () => {
        return (
            {flights}
        )
    }

    handleChangeFlight = event => { 
        const manageInflightPassengers = {...this.state.manageInflightPassengers, flightNumber:event};
        debugger;
        this.setState({ manageInflightPassengers});
    };
    handleChangePassenger = event => { 
        const manageInflightPassengers = {...this.state.manageInflightPassengers, passengerId:event};
        debugger;
        this.setState({ manageInflightPassengers});
    };

    handleChangeMealsPrefernce = event => { 
        const manageInflightPassengers = {...this.state.manageInflightPassengers, mealsPreference:event};
        debugger;
        this.setState({ manageInflightPassengers});
    };

    handleChangeShoppingRequest = event => { 
        const manageInflightPassengers = {...this.state.manageInflightPassengers, shoppingRequest:event};
        debugger;
        this.setState({ manageInflightPassengers});
    };

    
    updatePassengerList = (flightNumber, passengerId, mealsPreference, shoppingRequest) => {
        debugger;
        let passengers =[];
        let meals = [];
        let shopping = [];
        this.props.passengers.map(passenger => (
          (passenger.passengerId === passengerId && passenger.flightNumber.label === flightNumber) ? 
          [ 
          passenger.mealsPreference.map(data => (meals.push(data))),
          meals.push(mealsPreference),
          passenger.shoppingRequest.map(data => (shopping.push(data))),
          shopping.push(shoppingRequest),
          passengers.push(
            {
            "flightNumber" : passenger.flightNumber,
            "passengerId": passenger.passengerId,
            "firstName": passenger.firstName,
            "lastName": passenger.lastName,
            "seat": passenger.seat,
            "dob": passenger.dob,
            "address": passenger.address,
            "country": passenger.country,
            "state": passenger.state,
            "city": passenger.city,
            "mobile": passenger.mobile,
            "email": passenger.email,
            "passport": passenger.passport,
            "scheduledTime": passenger.scheduledTime,
            "ancilaryServiceData": passenger.ancilaryServiceData,
            "checkin": passenger.checkin,
            "wheelChair": passenger.wheelChair,
            "infants": passenger.infants,
            "specialMeals": passenger.specialMeals,
            "mealsPreference": meals,
            "shoppingRequest": shopping
            }
          ) ]
          : passengers.push(passenger)
        ))

        return (
            passengers
        )
    }

    handleInFlightServices = event => {
        debugger;
        let updatedPassenger = this.updatePassengerList(
            this.state.manageInflightPassengers.flightNumber.label,
            this.state.manageInflightPassengers.passengerId.value,
            this.state.manageInflightPassengers.mealsPreference, this.state.manageInflightPassengers.shoppingRequest);
        debugger;
        this.props.actions.updatePassengerAction(updatedPassenger)
        console.log("after inflight service updation: " + updatedPassenger);
    };

    arrayList = () => {
        let arrayList = [];
          debugger;
          this.props.passengers.map(passenger => ( (passenger.flightNumber !== null && passenger.flightNumber !== "" && passenger.flightNumber !== undefined) ? (passenger.flightNumber.label === this.state.manageInflightPassengers.flightNumber.label) ?
              arrayList.push({"label":passenger.firstName +","+ passenger.lastName, "value":passenger.passengerId})
              : (console.log("no passenger namatched")) : (console.log("no valod flifht number"))
          )) 
         return (
          arrayList
         )
      }

      mealsArrayList = () => {
        let arrayList = [];
          debugger;
          this.props.mealsPreferencePerFlight.map(meals => ( (meals.flightNumber !== null && meals.flightNumber !== "" && meals.flightNumber !== undefined) ? (meals.flightNumber.label === this.state.manageInflightPassengers.flightNumber.label) ?
              arrayList.push({"label":meals.mealsPreference.label, "value":meals.mealsPreference.value, "desc": meals.mealsPreference.desc})
              : (console.log("no meals items")) : (console.log("no valid flight number"))
          )) 
         return (
          arrayList
         )
      }

      shoppingArrayList = () => {
        let arrayList = [];
          debugger;
          this.props.shoppingRequestPerFlight.map(shopping => ( (shopping.flightNumber !== null && shopping.flightNumber !== "" && shopping.flightNumber !== undefined) ? (shopping.flightNumber.label === this.state.manageInflightPassengers.flightNumber.label) ?
              arrayList.push({"label":shopping.shoppingRequest.label, "value":shopping.shoppingRequest.value})
              : (console.log("no shopping items")) : (console.log("no valid flight number"))
          )) 
         return (
          arrayList
         )
      }

    render() {
        const {flightNumber, passengerId, mealsPreference, shoppingRequest } = this.state.manageInflightPassengers;
        return (
            <form>
                <div className="container">
                <div className="row" style={{'padding':'5px'}}><h4>Passenger In-Flight Services</h4> </div>
                    <div className="row" style={{'padding':'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="flightNumber">Select Flight*</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeFlight}  placeholder="select flight" options={flights} value={flightNumber} />
                        </div>
                    </div>
                    <div className="row" style={{'padding':'5px'}}>
                   
                        <div className="col-md-3">
                            <label htmlFor="passengerId">Select Passenger*</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="passengerId" id="passengerId" onChange={this.handleChangePassenger}  placeholder="select passenger" options={this.arrayList()} value={passengerId} />
                        </div>
                    </div>
                <div className="row" style={{'padding':'5px'}}>
                   
                   <div className="col-md-3">
                       <label htmlFor="mealsPreference">Request your Meals Preference*</label>
                   </div>
                   <div className="col-md-3">
                       <Select name="mealsPreference" id="mealsPreference" onChange={this.handleChangeMealsPrefernce}  placeholder="select Meals" options={this.mealsArrayList()} value={mealsPreference} />
                   </div>
               </div>
               <div className="row" style={{'padding':'5px'}}>
                   <div className="col-md-3">
                       <label htmlFor="shoppingRequest">Request your shop item*</label>
                   </div>
                   <div className="col-md-3">
                       <Select name="shoppingRequest" id="shoppingRequest" onChange={this.handleChangeShoppingRequest}  placeholder="select shopping item" options={this.shoppingArrayList()} value={shoppingRequest} />
                   </div>
                   <div className="col-md-3">
                           <input type="button" onClick={() => {this.handleInFlightServices()}} value="Request" style={{backgroundColor:"lightblue"}}  />
                    </div>
               </div>
                </div>
                <div className="container" >
                    <div className="row" style={{'padding':'5px'}}>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Flight</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Passenger Name</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Seat</div>
                        <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Meals Preference</div>
                        <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Shopping Requested</div>
                    </div>
                
                    {this.props.passengers.map(passenger => (
                        (passenger.passengerId === this.state.manageInflightPassengers.passengerId.value) ?
                        <div className="row" key={passenger.passengerId}>
                            <div className="col-md-1" >{passenger.flightNumber.label}</div>
                            <div className="col-md-2" >{passenger.firstName +" "+passenger.lastName}</div>
                            <div className="col-md-1" >{passenger.seat}</div>
                            <div className="col-md-3" >{passenger.mealsPreference.map(data => (data.label+" : "+data.desc))}</div>
                            <div className="col-md-3" >{passenger.shoppingRequest.map(data => (data.label+","))}</div>
                        </div>
                        : console.log("passenger not avaialble in current flight")
                    ))}
                </div>
            </form>
                        
        )
    }
}

ManageInFlightService.propsType = {
    passengers: PropTypes.array.isRequired,
    shoppingRequestPerFlight: PropTypes.array.isRequired,
    mealsPreferencePerFlight: PropTypes.array.isRequired,
    actions: PropTypes.object.isRequired
};


function mapStateToProps (state) {
    debugger;
    return {
        passengers: state.passengers,
        shoppingRequestPerFlight: state.shoppingRequestPerFlight,
        mealsPreferencePerFlight: state.mealsPreferencePerFlight
    };
}

function mapDispatchtoProps(dispatch) {
    return {
        actions: bindActionCreators( passengerAction , dispatch)
    }
}

export default connect(mapStateToProps,
    mapDispatchtoProps
    )(ManageInFlightService);