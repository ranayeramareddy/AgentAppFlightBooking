import React from 'react'
import Select from 'react-select';
import {flights} from "../staticData/mataData";
import SeatPicker from 'react-seat-picker'
import {connect} from "react-redux";
import * as updatePassengerSeatAction from "../../redux/actions/passengerAction";
import * as currentScheduledFlightCheckinMap from "../../redux/actions/currentScheduledFlightsAction";
import PropTypes from "prop-types";
import {bindActionCreators} from "redux";
 
class InFlightDashboard extends React.Component {
 
  state = {
    currentScheduledFlights : {
      flightNumber: "",
      loading: false,
      passengersList:[],
      rows : [
        [
            {id: 1, number: 1, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 2, number: 2, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            null, 
            {id: 3, number: 3, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 4, number: 4, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 5, number: 5, isSelected: false, isReserved: false, tooltip: 'Reserved by you'},
            {id: 6, number: 6, isSelected: false, isReserved: false, tooltip: 'Reserved by you'},
            null,
            {id: 7, number: 7, isSelected: false, isReserved: false, tooltip: 'Reserved by you'},
            {id: 8, number: 8, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}
        ],
        [
            {id: 7, number: 1, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 8, number: 2, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            null, 
            {id: 9, number: 3, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 10, number: 4, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 11, number: 5, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 12, number: 6, isSelected: false, isReserved: false, tooltip: 'Reserved by you'},
            null,
            {id: 13, number: 7, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 14, number: 8, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
        ],
        [
            {id: 15, number: 1, isSelected: false, isReserved: false, tooltip: 'Reserved for infants'}, 
            {id: 16, number: 2, isSelected: false, isReserved: false, tooltip: 'Reserved for infants'}, 
            null, 
            {id: 17, number: 3, isSelected: false, isReserved: false, tooltip: 'Reserved for infants'}, 
            {id: 18, number: 4, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 19, number: 5, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 20, number: 6, isSelected: false, isReserved: false, tooltip: 'Reserved by you'},
            null,
            {id: 21, number: 7, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 22, number: 8, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
        ],
        [
            {id: 23, number: 1, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 24, number: 2, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            null, 
            {id: 25, number: 3, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 26, number: 4, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 27, number: 5, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 28, number: 6, isSelected: false, isReserved: false, tooltip: 'Reserved by you'},
            null,
            {id: 29, number: 7, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 30, number: 8, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
        ],
        [
            {id: 31, number: 1, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 32, number: 2, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            null, 
            {id: 33, number: 3, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 34, number: 4, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 35, number: 5, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 36, number: 6, isSelected: false, isReserved: false, tooltip: 'Reserved by you'},
            null,
            {id: 37, number: 7, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
            {id: 38, number: 8, isSelected: false, isReserved: false, tooltip: 'Reserved by you'}, 
        ],
      ]
    },
  };

  flights = () =>{
      debugger;
      return (
          {flights}
      )
  }

  
/*static getDerivedStateFromProps(props, state) {
  
}*/

  handleChangeFlight = event => { 
      const currentScheduledFlights = {...this.state.currentScheduledFlights, flightNumber:event};
      debugger;
       this.setState({ currentScheduledFlights});
  };

  handleChange = event => { 
    const currentScheduledFlights = {...this.state.currentScheduledFlights, passengersList:event};
    debugger;
     this.setState({ currentScheduledFlights});
};
 
  addSeatCallbackContinousCase = ({ row, number, id }, addCb, params, removeCb) => {
      debugger;
      const currentseat = {...this.state.currentScheduledFlights, loading:true};
    this.setState({
        currentseat
    }, async () => {
      if (removeCb) {
        await new Promise(resolve => setTimeout(resolve, 750))
        console.log(`Removed seat ${params.number}, row ${params.row}, id ${params.id}`)
        removeCb(params.row, params.number)
      }
      await new Promise(resolve => setTimeout(resolve, 750))
      console.log(`Added seat ${number}, row ${row}, id ${id}`)
      const newTooltip = `tooltip for id-${id} added by callback`
      addCb(row, number, id, newTooltip)
      const currentaddedlights = {...this.state.currentScheduledFlights, loading: false};
      this.setState({ currentaddedlights })
      const seat=row+number;
      const passenger=this.state.currentScheduledFlights.passengersList.value;
      console.log("SEAT:::"+seat+",,,, passengerId:::::"+passenger)
      this.checkinPassengerList(passenger, seat, true);
    })
  }
 
  removeSeatCallback = ({ row, number, id }, removeCb) => {
      debugger;
    const currentremovedlights = {...this.state.currentScheduledFlights, loading: true};
    this.setState({
        currentremovedlights
    }, async () => {
      await new Promise(resolve => setTimeout(resolve, 1500))
      console.log(`Removed seat ${number}, row ${row}, id ${id}`)
      // A value of null will reset the tooltip to the original while '' will hide the tooltip
      const newTooltip = ['A', 'B', 'C'].includes(row) ? null : ''
      removeCb(row, number, newTooltip)
      const currentlights = {...this.state.currentScheduledFlights, loading: false};
      this.setState({ currentlights })
      const seat=row+number;
      const passenger=this.state.currentScheduledFlights.passengersList.value;
      console.log("SEAT:::"+seat+",,,, passengerId:::::"+passenger)
      this.checkinPassengerList(passenger, seat, false);
    })
  }
/*
  handleSubmit = event => {
    event.preventDefault();
    debugger;
    this.props.actions.seatMapPassenger(this.props.passengers, 
    this.state.currentScheduledFlights.flightNumber.label )
    console.log(this.state.currentScheduledFlights);
    
};
*/
arrayList = () => {
  let arrayList = [];
    debugger;
     
    this.props.passengers.map(passenger => ( (passenger.flightNumber !== null && passenger.flightNumber !== "" && passenger.flightNumber !== undefined) ? (passenger.flightNumber.label === this.state.currentScheduledFlights.flightNumber.label) ?
        arrayList.push({"label":passenger.firstName +","+ passenger.lastName, "value":passenger.passengerId})
        [this.updateSeat(passenger.seat, passenger.checkin)]
        : (console.log("no passenger namatched")) : (console.log("no valod flifht number"))
    )) 
   return (
    arrayList
   )
}

  checkinPassengerList = (selectedPassenger, seat, checkin) => {
    //event.preventDefault();
    debugger;
    let passengers =[];
    this.props.passengers.map(passenger => (
      passenger.passengerId === selectedPassenger ? 
      passengers.push(
        {
        "flightNumber" : passenger.flightNumber,
        "passengerId":passenger.passengerId,
        "firstName":passenger.firstName,
        "lastName":passenger.lastName,
        "seat":seat,
        "dob":passenger.dob,
        "address":passenger.address,
        "country": passenger.country,
        "state": passenger.state,
        "city":passenger.city,
        "mobile":passenger.mobile,
        "email":passenger.email,
        "passport":passenger.passport,
        "scheduledTime":passenger.scheduledTime,
        "ancilaryServiceData":passenger.ancilaryServiceData,
        "checkin": checkin,
        "wheelChair": passenger.wheelChair,
        "infants": passenger.infants,
        "specialMeals": passenger.specialMeals,
        "mealsPreference": passenger.mealsPreference,
        "shoppingRequest": passenger.shoppingRequest
        }
      ) 
      [this.updateSeat(seat, checkin, passenger.infants, passenger.wheelChair)]
      : passengers.push(passenger)
    ))


    //this.props.actions.updatePassengerAction(passengers, selectedPassenger, seat, checkin)
    this.props.actions.updatePassengerAction(passengers)
    console.log(passengers);
    debugger;
    this.props.checkinMaps.createScheduledCheckinPassengerAction(this.state.currentScheduledFlights)
  }

updateSeat =(seat, checkin, infants, wheelChair) => {
  if(seat !== "" && seat !== null) {
    const row = seat.split("")[0];
    const number = seat.split("")[1];
    let line = 0;
    (row==="A") ? line=0 : (row==="B")?line=1:(row==="C")?line=2:(row==="D")?line=3:(row==="E")?row=4:line=0
    if(number === this.state.currentScheduledFlights.rows[line].number) {
      this.state.currentScheduledFlights.rows[line].isSelected = checkin;
      if(infants){
        this.state.currentScheduledFlights.rows[line].isReserved = infants;
        this.state.currentScheduledFlights.rows[line].tooltip= "reserved for infants"
      }
      if(wheelChair){
        this.state.currentScheduledFlights.rows[line].isReserved = wheelChair;
        this.state.currentScheduledFlights.rows[line].tooltip= "reserved for wheelChair passengers";
      }
    }
  }
}
 
  render() {


    const {loading} = this.state.currentScheduledFlights;
    const {flightNumber} = this.state.currentScheduledFlights;
    const {passengersList} = this.state.currentScheduledFlights;

    return (
        <form onSubmit={this.handleSubmit}>
           
            <div className="container">
                <h5> In-Flight Services Dashboard</h5> <br/>
                <div className="row" style={{padding:'5px'}}>
                    <div className="col-md-3">
                        <label htmlFor="flightNumber">Choose Flight to View Details:</label>
                    </div>
                    <div className="col-md-3">
                        <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeFlight}  placeholder="select flight" options={flights} value={flightNumber} />
                    </div>
                   
                </div>
                <div className="row" style={{padding:'5px'}}>
                    <div className="col-md-3">
                        <label htmlFor="passengerId">Choose Passenger to Map Seat:</label>
                    </div>
                    <div className="col-md-3">
                        <Select name="passengerId" id="passengerId" onChange={this.handleChange}  placeholder="select passenger" options={this.arrayList()} value={passengersList} />
                    </div>
                </div>
            </div>
            <div className="container">
                <div className="row" style={{ marginTop: '50px', marginLeft: '50px' }}>
                    <div  className="col-md-4">
                        <SeatPicker
                            addSeatCallback={this.addSeatCallbackContinousCase}
                            removeSeatCallback={this.removeSeatCallback}
                            rows={(this.props.currentScheduledFlightCheckinMap !== null && this.props.currentScheduledFlightCheckinMap !== undefined && this.props.currentScheduledFlightCheckinMap.length > 0) ? (this.props.currentScheduledFlightCheckinMap.rows !== null && this.props.currentScheduledFlightCheckinMap.rows !== undefined && this.props.currentScheduledFlightCheckinMap.rows.length > 0)  ? this.props.currentScheduledFlightCheckinMap.rows : this.state.currentScheduledFlights.rows : this.state.currentScheduledFlights.rows}
                            maxReservableSeats={10}
                            alpha
                            visible
                            selectedByDefault
                            loading={loading}
                            tooltipProps={{ multiline: true }}
                            continuous
                        />
                    </div>
                    <div  className="col-md-2"></div>
                    <div  className="col-md-4">
                    <label > <h4>Selected Flight Details</h4> </label> <br/>
                        <label > <b>Airlines Name : </b> {flightNumber.airlinesName}</label> <br/>
                        <label ><b>Flight Number : </b>{flightNumber.label}</label> <br/>
                        <label ><b>Boarding Point :</b> {flightNumber.boarding}</label> <br/>
                        <label ><b>Destination :</b> {flightNumber.destination}</label> <br/>
                        <label ><b>Seating Capacity : 40</b></label>
                    </div>
                </div>
                <div className="row" style={{ marginTop: '50px', marginLeft: '50px' }}>
                <div className="col-md-5">note*: Green = checkin ; Blue= not checkin; Greay= special meals passengers</div>
                </div>
            </div>
        </form>
        
    );
  }
}

InFlightDashboard.propsType = {
    passengers: PropTypes.array.isRequired,
    seatMapPassengers: PropTypes.array.isRequired,
    actions: PropTypes.object.isRequired,
    checkinMaps: PropTypes.object.isRequired
};


function mapStateToProps (state) {
    debugger;
    return {
       passengers: state.passengers,
       currentScheduledFlightCheckinMap: state.currentScheduledFlightCheckinMap
    };
}

function mapDispatchtoProps(dispatch) {
    return {
        actions: bindActionCreators( updatePassengerSeatAction, dispatch),
        checkinMaps: bindActionCreators(currentScheduledFlightCheckinMap, dispatch)
    }
}

export default connect(mapStateToProps,
    mapDispatchtoProps
    )(InFlightDashboard);