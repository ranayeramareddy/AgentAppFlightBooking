import React from "react";
import {connect} from "react-redux";
import * as checkinPassengerAction from "../../redux/actions/checkinPassengersAction";
import PropTypes from "prop-types";
import Select from 'react-select';
import {flights} from "../staticData/mataData";
import {bindActionCreators} from "redux";


class CheckinPassengerService extends React.Component {
    state = {
      checkinPassengerList : {
        flightNumber: "",
      },
    };

    flights = () =>{
        return (
            {flights}
        )
    }

    handleChangeFlight = event => { 
        const checkinPassengerList = {...this.state.checkinPassengerList, flightNumber:event};
        debugger;
         this.setState({ checkinPassengerList});
    };

    addZero = i => {
        if (i < 10) {
            i = '0' + i;
        }
        return i;
    }

    formatDate = (date) => {
        let dateTime = '';
        let d = new Date(date),
            month = '' + this.addZero(d.getMonth() + 1),
            day = '' + this.addZero(d.getDate()),
            year = d.getFullYear();
        dateTime = [ year, month, day ].join('/') ;
        return dateTime;
    }
    formatDateTime = (date) => {
        let dateTime = '';
        let d = new Date(date),
            month = '' + this.addZero(d.getMonth() + 1),
            day = '' + this.addZero(d.getDate()),
            year = d.getFullYear();
        let hour = this.addZero(d.getHours());
        let min = this.addZero(d.getMinutes());
        dateTime = [ year, month, day ].join('/') + ' ' + hour + ':' + min ;
        return dateTime;
    }

    handleDetails = (checkinSearchPassengers, passengerId) =>{
        debugger;
    };

    handleSubmit = event => {
        event.preventDefault();
        debugger;
        this.props.actions.checkinSearchPassenger(this.props.passengers, 
            this.state.checkinPassengerList.flightNumber.label )
        console.log(this.state.checkinPassengerList);
        
    };


    render() {
        const {flightNumber} = this.state.checkinPassengerList
       
        return (
            <form onSubmit={this.handleSubmit}>
                <h5> Booked Passengers List for Flight :{flightNumber.label}</h5> <br/>
                <div className="container">
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="flightNumber">Chose Flight to show passengers*</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeFlight}  placeholder="select flight" options={flights} value={flightNumber} />
                        </div>
                    </div>
                </div>
                <div className="container" style={{display:'block', width:'100%', height:'300px', overflow:'scroll'}}>
                    <div className="row" style={{padding:'5px'}}>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Passenger Id</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Passenger Name</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Seat</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Passport</div>
                        <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Ancilary Services</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Sechduled Time</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Action</div>
                    </div>
             
                
                        {this.props.passengers.map(passenger => (
                            (passenger.flightNumber.label === flightNumber.label) ?
                            <div className="row" key={passenger.passengerId}>
                                <div className="col-md-1" >{passenger.passengerId}</div>
                                <div className="col-md-2" >{passenger.firstName +" "+passenger.lastName}</div>
                                <div className="col-md-1" >{passenger.seat}</div>
                                <div className="col-md-1" >{passenger.passport}</div>
                                <div className="col-md-3" >{passenger.ancilaryServiceData.map(data => (data.label+","))}</div>
                                <div className="col-md-2" >{this.formatDateTime(passenger.scheduledTime)}</div>
                                <div className="col-md-1"><input type="button" value="Details" onClick={ () => {this.handleDetails(this.props.checkinSearchPassengers, passenger.passengerId)}} /></div>
                            </div>
                            : console.log("no passengers for selected flight")
                        ))}
                </div>
            </form>
                        
        )
    }
}

CheckinPassengerService.propsType = {
    passengers: PropTypes.array.isRequired,
    checkinSearchPassengers: PropTypes.array.isRequired,
    actions: PropTypes.object.isRequired
};


function mapStateToProps (state) {
    debugger;
    return {
        passengers: state.passengers,
        checkinSearchPassengers: state.checkinSearchPassengers
    };
}

function mapDispatchtoProps(dispatch) {
    return {
        actions: bindActionCreators( checkinPassengerAction , dispatch)
    }
}

export default connect(mapStateToProps,
    mapDispatchtoProps
    )(CheckinPassengerService);