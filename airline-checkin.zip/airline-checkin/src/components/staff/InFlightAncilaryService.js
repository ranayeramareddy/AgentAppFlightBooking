import React from "react";
import {connect} from "react-redux";
import * as passengerAction from "../../redux/actions/passengerAction";
import PropTypes from "prop-types";
import Select from 'react-select';
import {flights} from "../staticData/mataData";
import {bindActionCreators} from "redux";

class InFlightAncilaryService extends React.Component {
    state = {
      inflightPassengers : {
        flightNumber: "",
        passengerId: "",
        ancilaryServiceInflight: ""
      }
    };

    flights = () =>{
        return (
            {flights}
        )
    }
    handleChangeFlight = event => { 
        const inflightPassengers = {...this.state.inflightPassengers, flightNumber:event};
        debugger;
        this.setState({ inflightPassengers});
    };
    handleChangePassenger = event => { 
        const inflightPassengers = {...this.state.inflightPassengers, passengerId:event};
        debugger;
        this.setState({ inflightPassengers});
    };

    handleChangeAncilaryData = event => { 
        const inflightPassengers = {...this.state.inflightPassengers, ancilaryServiceInflight:event};
        debugger;
        this.setState({ inflightPassengers});
    };

    addZero = i => {
        if (i < 10) {
            i = '0' + i;
        }
        return i;
    }

    formatDate = (date) => {
        let dateTime = '';
        let d = new Date(date),
            month = '' + this.addZero(d.getMonth() + 1),
            day = '' + this.addZero(d.getDate()),
            year = d.getFullYear();
        
        dateTime = [ year, month, day ].join('/') ;
        return dateTime;
    }
    formatDateTime = (date) => {
        let dateTime = '';
        let d = new Date(date),
            month = '' + this.addZero(d.getMonth() + 1),
            day = '' + this.addZero(d.getDate()),
            year = d.getFullYear();
        let hour = this.addZero(d.getHours());
        let min = this.addZero(d.getMinutes());
        
        dateTime = [ year, month, day ].join('/') + ' ' + hour + ':' + min ;
        return dateTime;
    }

    updatePassengerList = (flightNumber, passengerId, ancilaryServiceInflightOb) => {
        debugger;
        let passengers =[];
        let newAncilaryList = [];
        this.props.passengers.map(passenger => (
          (passenger.passengerId === passengerId && passenger.flightNumber.label === flightNumber) ? 
          [ 
          passenger.ancilaryServiceData.map(data => (newAncilaryList.push(data))),
          newAncilaryList.push(ancilaryServiceInflightOb),
          passengers.push(
            {
            "flightNumber" : passenger.flightNumber,
            "passengerId": passenger.passengerId,
            "firstName": passenger.firstName,
            "lastName": passenger.lastName,
            "seat": passenger.seat,
            "dob": passenger.dob,
            "address": passenger.address,
            "country": passenger.country,
            "state": passenger.state,
            "city": passenger.city,
            "mobile": passenger.mobile,
            "email": passenger.email,
            "passport": passenger.passport,
            "scheduledTime": passenger.scheduledTime,
            "ancilaryServiceData": newAncilaryList,
            "checkin": passenger.checkin,
            "wheelChair": passenger.wheelChair,
            "infants": passenger.infants,
            "specialMeals": passenger.specialMeals,
            "mealsPreference": passenger.mealsPreference,
            "shoppingRequest": passenger.shoppingRequest
            }
          ) ]
          : passengers.push(passenger)
        ))

        return (
            passengers
        )
    }

    handleAddAncilary = event => {
       // event.preventDefault();
        debugger;
        let updatedPassenger = this.updatePassengerList(
            this.state.inflightPassengers.flightNumber.label,
            this.state.inflightPassengers.passengerId.value,
            this.state.inflightPassengers.ancilaryServiceInflight);
        debugger;
        this.props.actions.updatePassengerAction(updatedPassenger)
        console.log("after ancilary updation: " + updatedPassenger);
    };

    arrayList = () => {
        let arrayList = [];
          debugger;
          this.props.passengers.map(passenger => ( (passenger.flightNumber !== null && passenger.flightNumber !== "" && passenger.flightNumber !== undefined) ? (passenger.flightNumber.label === this.state.inflightPassengers.flightNumber.label) ?
              arrayList.push({"label":passenger.firstName +","+ passenger.lastName, "value":passenger.passengerId})
              : (console.log("no passenger namatched")) : (console.log("no valod flifht number"))
          )) 
         return (
          arrayList
         )
      }


    ancilaryList = () => {
        let arrayList = [];
        this.props.flightAncilaryServices.map(service => ((service.flightNumber !== null && service.flightNumber !== "" && service.flightNumber !== undefined) ? (service.flightNumber.label === this.state.inflightPassengers.flightNumber.label) ?
                arrayList.push({"label":service.ancilaryServices.label, "value":service.ancilaryServices.value})
            :  console.log("no ancilary for this flight")
            :  console.log("no valid flight number")
            ))
        
        return (
            arrayList
        )
    }

    render() {
        const {flightNumber, passengerId, ancilaryServiceInflight} = this.state.inflightPassengers;
        return (
            <form>
                <div className="container">
                <div className="row" style={{'padding':'5px'}}><h4>Passenger Ancilary Services</h4> </div>
                    <div className="row" style={{'padding':'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="flightNumber">Select Flight*</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="flightNumber" id="flightNumber" onChange={this.handleChangeFlight}  placeholder="select flight" options={flights} value={flightNumber} />
                        </div>
                    </div>
                    <div className="row" style={{'padding':'5px'}}>
                   
                        <div className="col-md-3">
                            <label htmlFor="passengerId">Select Passenger*</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="passengerId" id="passengerId" onChange={this.handleChangePassenger}  placeholder="select flight" options={this.arrayList()} value={passengerId} />
                        </div>
                    </div>
                </div>
                <div className="container" >
                    <div className="row" style={{'padding':'5px'}}>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Flight</div>
                        <div className="col-md-2" style={{backgroundColor:"lightblue"}}>Passenger Name</div>
                        <div className="col-md-1" style={{backgroundColor:"lightblue"}}>Seat</div>
                        <div className="col-md-3" style={{backgroundColor:"lightblue"}}>Ancilary Services</div>
                    </div>
                
                    {this.props.passengers.map(passenger => (
                        (passenger.passengerId === this.state.inflightPassengers.passengerId.value) ?
                        <div className="row" key={passenger.passengerId}>
                            <div className="col-md-1" >{passenger.flightNumber.label}</div>
                            <div className="col-md-2" >{passenger.firstName +" "+passenger.lastName}</div>
                            <div className="col-md-1" >{passenger.seat}</div>
                            <div className="col-md-3" >{passenger.ancilaryServiceData.map(data => (data.label+","))}</div>
                        </div>
                        : console.log("passenger not avaialble in current flight")
                    ))}
                </div>
                <div className="container"><br /> <br /> <br />
                    <div className="row" style={{'padding':'5px'}}><h4>Add Ancilary Services to Selected Passenger</h4> </div>
                    <div className="row" style={{'padding':'5px'}}>
                        <div className="col-md-3">
                            <label htmlFor="ancilaryServiceInflight">Select Ancilary Service*</label>
                        </div>
                        <div className="col-md-3">
                            <Select name="ancilaryServiceInflight" id="ancilaryServiceInflight" onChange={this.handleChangeAncilaryData}  placeholder="select Ancilary Service" options={this.ancilaryList()} value={ancilaryServiceInflight} />
                        </div>
                        <div className="col-md-3">
                           <input type="button" onClick={() => {this.handleAddAncilary()}} value="Add Ancilary Service" style={{backgroundColor:"lightblue"}}  />
                        </div>
                        
                    </div>
                </div>
            </form>
                        
        )
    }
}

InFlightAncilaryService.propsType = {
    passengers: PropTypes.array.isRequired,
    flightAncilaryServices: PropTypes.array.isRequired,
    actions: PropTypes.object.isRequired
};


function mapStateToProps (state) {
    debugger;
    return {
        passengers: state.passengers,
        flightAncilaryServices: state.flightAncilaryServices
    };
}

function mapDispatchtoProps(dispatch) {
    return {
        actions: bindActionCreators( passengerAction , dispatch)
    }
}

export default connect(mapStateToProps,
    mapDispatchtoProps
    )(InFlightAncilaryService);