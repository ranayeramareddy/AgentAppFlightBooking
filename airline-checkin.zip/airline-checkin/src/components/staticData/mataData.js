
export const  flights = [
    { label: "UL461", value: 'UL461', boarding:'Chennai', destination:'Tokyo', airlinesName: 'Srilanka Airlines' },
    { label: "UL125", value: 'UL125', boarding:'Hyderabad', destination:'Delhi', airlinesName: 'Srilanka Airlines'  },
    { label: "UL462", value: 'UL462', boarding:'Bangalore', destination:'Tokyo', airlinesName: 'Srilanka Airlines'  },
    { label: "UL126", value: 'UL126', boarding:'Chennai', destination:'London', airlinesName: 'Srilanka Airlines'  },
    { label: "UL463", value: 'UL463', boarding:'Chennai', destination:'Newyork', airlinesName: 'Srilanka Airlines'  },
    { label: "UL127", value: 'UL127', boarding:'Chennai', destination:'Germany', airlinesName: 'Srilanka Airlines'  },
    { label: "UL430", value: 'UL430', boarding:'Chennai', destination:'Tokyo', airlinesName: 'Srilanka Airlines' },
    { label: "UL908", value: 'UL908', boarding:'Hyderabad', destination:'Delhi', airlinesName: 'Srilanka Airlines'  },
    { label: "UL405", value: 'UL405', boarding:'Bangalore', destination:'Tokyo', airlinesName: 'Srilanka Airlines'  },
    { label: "UL104", value: 'UL104', boarding:'Chennai', destination:'London', airlinesName: 'Srilanka Airlines'  },
    { label: "UL103", value: 'UL103', boarding:'Chennai', destination:'Newyork', airlinesName: 'Srilanka Airlines'  },
    { label: "UL102", value: 'UL102', boarding:'Chennai', destination:'Germany', airlinesName: 'Srilanka Airlines'  },
];

export const  countries = [
    { label: "India", value: 'India' },
    { label: "USA", value: 'USA' },
    { label: "UK", value: 'UK' },
    { label: "Japan", value: 'Japan' },
    { label: "Srilanka", value: 'Srilanka' },
    { label: "Chaina", value: 'Chaina' },
];

export const  states = [
    { label: "Tamilnadu", value: 'Tamilnadu' },
    { label: "Karnataka", value: 'Karnataka' },
    { label: "Kawasaki", value: 'Kawasaki' },
    { label: "New Jersy", value: 'New Jersy' },
    { label: "Telangana", value: 'Telangana' },
    { label: "Telangana", value: 'Telangana' },
];


export const  cities = [
    { label: "Hyderabad", value: 'Hyderabad' },
    { label: "Bangalore", value: 'Bangalore' },
    { label: "Colombo", value: 'Colombo' },
    { label: "Bejing", value: 'Bejing' },
    { label: "Tokyo", value: 'Tokyo' },
    { label: "Osaka", value: 'Osaka' },
    { label: "New York", value: 'New York' },
    { label: "London", value: 'London' },
];

export const  ancilary = [
    { label: "excess-baggage", value: 'excess-baggage' },
    { label: "Frequent-flyer-programs ", value: 'Frequent-flyer-programs ' },
    { label: "Lounge-access", value: 'Lounge-access' },
    { label: "Sky-bazaar", value: 'Sky-bazaar' },
    { label: "Miles", value: 'Miles' },
    { label: "In-flight-entertainment", value: 'In-flight-entertainment' },
    { label: "Inflight-meals", value: 'Inflight-meals' }
];


export const  mealsPreferences = [
    { label: "indian-veg-breakfast", value: 'indian-veg-breakfast', desc: "tomoto rawa upma, sambar, cut fruits, vada, tamato Chutney" },
    { label: "indian-nonveg-breakfast", value: 'indian-nonveg-breakfast', desc: "parotta/chapati, cheken rost, cut fruits, juice" },
    { label: "indian-veg-lunch", value: 'indian-veg-lunch', desc:"fried rice, samber, salad, juice, raice, veg fry, manchuria, sweet"},
    { label: "indian-non-veg-lunch", value: 'indian-non-veg-lunch', desc:"checkn fry, checken biriyani, rice, fich cury, sweet"},
    { label: "chinese-Special", value: 'chinese-Special', desc:"chiken fry, fork dry, noodels, salad, drinks, choclete" },
    { label: "italy-Special", value: 'italy-Special', desc:"chiken fry, fork dry, bun, salad, drinks, choclete" },
];

export const  shoppingRequests = [
    { label: "Compact-Body-Massager", value: 'Compact-Body-Massager' },
    { label: "Foot-Massager", value: 'Foot-Massager' },
    { label: "Pain-Relief-Massager-Pen", value: 'Pain-Relief-Massager-Pen' },
    { label: "Charger-Cabels", value: 'Charger-Cabels' },
    { label: "Mobiles", value: 'Mobiles' },
    { label: "books", value: 'books' },
    { label: "laggage-bag-lockers", value: 'laggage-bag-lockers' }
];
