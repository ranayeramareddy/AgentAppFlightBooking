import React from 'react';
//import logo from './logo.svg';
import './index.css';
import AppLayoutWithHeader from "./components/login/AppLayoutWithHeader";
import 'bootstrap/dist/css/bootstrap.min.css';

function App(initialData) {
  return (
    <AppLayoutWithHeader />
  );
}

export default App;
