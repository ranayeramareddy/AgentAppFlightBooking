import * as types from "./actionTypes";

export function addAncilaryAction(addAncilaryService){
    debugger;
    return { 
        type: types.CREATE_ANCILARY, addAncilaryService:addAncilaryService
    };
}

export function deleteAddAncilaryAction(addAncilaryService, deleteId){
    debugger;
    return { 
        type: types.DELETE_ADDANCILARY, addAncilaryService:addAncilaryService, deleteId:deleteId
    };
}