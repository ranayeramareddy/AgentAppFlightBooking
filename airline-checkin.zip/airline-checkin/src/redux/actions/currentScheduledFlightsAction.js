import * as types from "./actionTypes";

export function createScheduledCheckinPassengerAction(checkinMap){
    debugger;
    return { 
        type: types.ADD_CHECKINMAP, checkinMap:checkinMap
    };
}