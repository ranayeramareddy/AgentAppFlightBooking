import * as types from "./actionTypes";

export function createAction(flightAncilaryService){
    debugger;
    return { 
        type: types.ADD_ANCILARYSERVICE, flightAncilaryService:flightAncilaryService
    };
}

export function deleteAction(flightAncilaryService, deleteId){
    debugger;
    return { 
        type: types.DELETE_ANCILARYSERVICE, flightAncilaryService:flightAncilaryService, deleteId:deleteId
    };
}



