import * as types from "./actionTypes";

export function checkinSearchPassenger(passenger, flightNumber){
    debugger;
    return { 
        type: types.CHECKIN_FILTER_PASSENGERS, passenger:passenger, flightNumber:flightNumber
    };
}
