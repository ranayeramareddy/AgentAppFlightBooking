import * as types from "./actionTypes";

export function createPassenger(passenger){
    debugger;
    return { 
        type: types.ADD_PASSENGERS, passenger:passenger
    };
}

export function deletePassenger(passenger, deleteId){
    debugger;
    return { 
        type: types.DELETE_PASSENGERS, passenger:passenger, deleteId:deleteId
    };
}

export function searchPassenger(passenger, flightNumber){
    debugger;
    return { 
        type: types.SEARCH_PASSENGERS, passenger:passenger, flightNumber:flightNumber
    };
}

export function filterPassenger(passenger, flightNumber, passport, dob, address){
    debugger;
    return { 
        type: types.FILTER_PASSENGERS, 
        passenger:passenger, 
        flightNumber:flightNumber,
        passport:passport,
        dob:dob,
        address:address
    };
}

export function filterAncilaryAction(flightAncilaryService, flightNumber){
    debugger;
    return { 
        type: types.FILTER_ANCILARY, flightAncilaryService:flightAncilaryService, flightNumber:flightNumber
    };
}

export function updatePassengerAction(passengers){
    debugger;
    return { 
        type: types.UPDATE_SEAT_PASSENGERS, 
        passengers:passengers
    };
}

export function filterCheckinPassengerAction(passenger, flightNumber, checkin, infants, wheelChair){
    debugger;
    return { 
        type: types.FILTER_CHECKIN_PASSENGERS,
        passenger:passenger, 
        flightNumber:flightNumber,
        checkin:checkin,
        infants:infants,
        wheelChair:wheelChair
    };
}
