import * as types from "./actionTypes";

export function createShoppingRequestAction(flightService){
    debugger;
    return { 
        type: types.ADD_SHOPPINGITEMS, flightService:flightService
    };
}

export function deleteShoppingRequestAction(flightService, deleteId){
    debugger;
    return { 
        type: types.DELETE_SHOPPINGITEMS, flightService:flightService, deleteId:deleteId
    };
}
