import * as types from "./actionTypes";

export function createMealsPreferenceAction(flightService){
    debugger;
    return { 
        type: types.ADD_MEALSPREFERENCE, flightService:flightService
    };
}

export function deleteMealsPerefrenecAction(flightService, deleteId){
    debugger;
    return { 
        type: types.DELETE_MEALSPREFERENCE, flightService:flightService, deleteId:deleteId
    };
}
