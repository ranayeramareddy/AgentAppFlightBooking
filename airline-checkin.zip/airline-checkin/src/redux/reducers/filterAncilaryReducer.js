import * as types from "../actions/actionTypes";

export default function filterAncilaryReducer(state =[], action){

    switch(action.type){
        case types.FILTER_ANCILARY :
            debugger;
            return [...action.flightAncilaryService.filter(flightService => flightService.flightNumber.label === action.flightNumber)];
        default :
            return state;
    }
}