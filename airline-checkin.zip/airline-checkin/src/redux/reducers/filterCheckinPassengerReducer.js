import * as types from "../actions/actionTypes";

export default function filterCheckinPassengerReducer(state =[], action){

    switch(action.type){
        
        case types.FILTER_CHECKIN_PASSENGERS :
            debugger;
            return [...action.passenger.filter(passenger => (
                (passenger.flightNumber.label === action.flightNumber) ?
                (action.checkin) ? (passenger.checkin === action.checkin) : 
                (action.infants) ? (passenger.infants === action.infants) :
                (action.wheelChair) ? (passenger.wheelChair === action.wheelChair)
                : console.log("not matched")
                : console.log("not matched")
                )
                )];
        default :
            return state;
    }
}