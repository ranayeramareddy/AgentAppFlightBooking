import {combineReducers} from "redux";
import passengers from "./passengerReducer";
import flightAncilaryServices from "./ancilaryReducer"
import addAncilaryServices from "./addAncilaryReducer"
import filterPassengerList from "./filterPassengerReducer"
import filterServiceList from "./filterServiceReducer"
import flightFilteredAncilaryList from "./filterAncilaryReducer"
import checkinSearchPassengers from "./checkinPassengersReducer"
import currentScheduledFlightCheckinMap from "./currentScheduleFlightsCheckinReducer"
import filterCheckinPassenger from "./filterCheckinPassengerReducer"
import mealsPreferencePerFlight from "./mealsPreferenceReducer"
import shoppingRequestPerFlight from "./shoppingRequestReducer"

const rootReducer = combineReducers({
    passengers: passengers,
    flightAncilaryServices: flightAncilaryServices,
    addAncilaryServices: addAncilaryServices,
    filterPassengerList: filterPassengerList,
    filterServiceList: filterServiceList,
    flightFilteredAncilaryList: flightFilteredAncilaryList,
    checkinSearchPassengers: checkinSearchPassengers,
    currentScheduledFlightCheckinMap:currentScheduledFlightCheckinMap,
    filterCheckinPassenger: filterCheckinPassenger,
    mealsPreferencePerFlight: mealsPreferencePerFlight,
    shoppingRequestPerFlight: shoppingRequestPerFlight
});

export default rootReducer