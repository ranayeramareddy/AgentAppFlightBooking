import * as types from "../actions/actionTypes";

export default function scheduleFlightsCheckinReducer(state =[], action){

    switch(action.type){
        case types.ADD_CHECKINMAP :
            debugger;
            return [...state, {...action.checkinMap}];
        default :
            return state;
    }
}