import * as types from "../actions/actionTypes";

export default function passengerReducer(state =[], action){

    switch(action.type){
        case types.ADD_PASSENGERS :
            debugger;
            return [...state, {...action.passenger}];
        case types.DELETE_PASSENGERS :
            debugger;
            return [...state.filter(service => service.passengerId !== action.deleteId)];
        case types.UPDATE_SEAT_PASSENGERS :
            debugger;
           /* return [...state, {...action.passengers.map(passenger => (
                passenger.passengerId === action.passengerId ? 
                [passenger.seat = action.seat, 
                passenger.checkin = action.checkin] : passenger))}];*/
            return [...action.passengers];
        default :
            return state;
    }
}