import * as types from "../actions/actionTypes";

export default function ancilaryReducer(state =[], action){

    switch(action.type){
        case types.ADD_ANCILARYSERVICE :
            debugger;
            return [...state, {...action.flightAncilaryService}];
        case types.DELETE_ANCILARYSERVICE :
            debugger;
            return [...state.filter(service => service.id !== action.deleteId)];
        default :
            return state;
    }
}