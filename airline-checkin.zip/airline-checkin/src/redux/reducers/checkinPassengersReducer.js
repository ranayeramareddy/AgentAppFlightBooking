import * as types from "../actions/actionTypes";

export default function checkinPassengerReducer(state =[], action){

    switch(action.type){
        case types.CHECKIN_FILTER_PASSENGERS :
            debugger;
            return [...action.passenger.filter(passenger => passenger.flightNumber.label === action.flightNumber)];
        default :
            return state;
    }
}