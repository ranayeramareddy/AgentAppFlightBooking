import * as types from "../actions/actionTypes";

export default function addAncilaryReducer(state =[], action){

    switch(action.type){
        case types.CREATE_ANCILARY :
            debugger;
            return [...state, {...action.addAncilaryService}];
        case types.DELETE_ADDANCILARY :
            debugger;
            return [...state.filter(service => service.serviceId !== action.deleteId)];
        default :
            return state;
    }
}