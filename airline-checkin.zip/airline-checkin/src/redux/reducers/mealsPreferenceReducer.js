import * as types from "../actions/actionTypes";

export default function mealsPreferenceReducer(state =[], action){

    switch(action.type){
        case types.ADD_MEALSPREFERENCE :
            debugger;
            return [...state, {...action.flightService}];
        case types.DELETE_MEALSPREFERENCE :
            debugger;
            return [...state.filter(service => service.id !== action.deleteId)];
        default :
            return state;
    }
}