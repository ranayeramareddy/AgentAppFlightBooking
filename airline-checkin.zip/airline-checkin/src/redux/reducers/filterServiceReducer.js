import * as types from "../actions/actionTypes";

export default function filterServiceReducer(state =[], action){

    switch(action.type){
        case types.FILTER_PASSENGERS :
            debugger;
            return [...action.passenger.filter(passenger => (
                (passenger.flightNumber.label === action.flightNumber) 
                && (passenger.passport === action.passport)
                && (passenger.dob === action.dob) 
                && (passenger.address === action.address)))];
        default :
            return state;
    }
}